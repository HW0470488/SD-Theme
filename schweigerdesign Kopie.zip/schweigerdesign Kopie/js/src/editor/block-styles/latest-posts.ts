import { registerBlockStyle } from "@wordpress/blocks";
import { __ } from "@wordpress/i18n";
import domReady from "@wordpress/dom-ready";

domReady(() => {

	/*
	registerBlockStyle("core/latest-posts", {

		name: "load-more",
		label: __("With \"Load more\" button", "gw-schweigerdesign")

	});
	*/
});
