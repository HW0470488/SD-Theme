/**
 * A category object.
 */

export interface Category {

	id: number;

}
