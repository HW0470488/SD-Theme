/**
 * A WordPress block type.
 */

export interface BlockType {

	name: string;

}
