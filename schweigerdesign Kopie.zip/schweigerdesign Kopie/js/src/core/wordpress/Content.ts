/**
 * Describes a WordPress content object.
 */

export interface Content {

	"protected": boolean;
	rendered: string;

}
